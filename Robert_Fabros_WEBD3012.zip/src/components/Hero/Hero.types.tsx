export interface HeroProps {
    title: string;
    subtitle?: string;
    backgroundImage?: string;
    className?: string;
    backgroundColor?: string;
}