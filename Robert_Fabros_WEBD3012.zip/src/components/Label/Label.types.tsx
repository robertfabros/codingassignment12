export interface LabelProps {
    text: string;
    htmlFor?: string;
    className?: string;
}