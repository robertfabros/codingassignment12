
export interface MyButtonProps {
    label?: string;
    primary?: boolean;
    disabled?: boolean; 
    style?: React.CSSProperties;   
  }
  