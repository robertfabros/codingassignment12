
export * from './smartrating'; // Add this line for each new component folder
