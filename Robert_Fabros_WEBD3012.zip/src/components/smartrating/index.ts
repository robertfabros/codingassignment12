export { default } from './SmartRating';
